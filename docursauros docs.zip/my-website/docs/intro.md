---
title: Welcome to the GRP Docs
sidebar_position: 1
tags: [intro, introduction]
---

# Welcome to the GRP Documentation

Welcome to the GRP Documentation, here you will find all about the Game and the Features.
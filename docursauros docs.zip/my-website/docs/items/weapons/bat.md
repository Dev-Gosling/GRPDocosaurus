---
sidebar_position: 1
---

# Bat
The Bat is the cheapest weapon which isnt illagal but not legal simultaneously
:::info NOT LEGAL simultaneously
As soon as you hit someone with a bat you get half-a-star which means you will be wanted for **30 Seconds**, while you are wanted the Bat is illegal and you can be arrested!
:::
## Statistics

### Price
The Bat costs $200 at the Sportshop.

### Damage
15 HP on the Body

### Distance
You can hit people with the bat if the bat touches a players character with enough speed

## Attachments
*The bat is not able to have any attachments*

:::caution Illegal Item
This item is ``stated as Illegal if`` you are wanted and the Police Team can arrest you if you have it in your inventory or in the trunk while being wanted.
:::
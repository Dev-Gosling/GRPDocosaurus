---
sidebar_position: 1
---

# Rocket Launcher
The Rocket Launcher Shoots Rockets and is currently unobtainable

## Obtainability
### How you could get it
:::info important information
Before you read how you **could** get it please remember that this way to get it is not guaranteed because the founder has the choice to give it to you or not.
:::
The Rocket Launcher was given to special people, like YouTubers, Gametesters, Teammembers and to a friend from the founder.

There are currently 5 people owning a Rocket Launcher according to the founder and only 2 People are known having one:
[Sofia00777770](https://www.roblox.com/users/2246931035/profile)

![Sofia00777770's Character](https://tr.rbxcdn.com/119bbd456c8eb945b7cd0f36513c94f5/420/420/Avatar/Png)

[DragonGamer_2303](https://www.roblox.com/users/1287146095/profile)

![DragonGamer_2303's Character](https://tr.rbxcdn.com/ad0ddf288fedb618a39adcbca8a1d3b0/420/420/Avatar/Png)

### Ways you could get the Rocket Launcher
The most easiest way to possibly get the Rocket Launcher is apply for a position in the Team and do good work to become a respected teammamber or to apply as a Gametester

## Statistics

:::tip Did you know?
The Rocket Launcher is the only Weapon which is not stated as illegal to the Police Team, also you cant Drop or Give this weapon.
:::

### Damage from the Point the Rocket Landed
*This values are estimated because this weapon doesnt show any hitpoints*
- 0-4 Studs: 120 HP
- 4-9 Studs: 100 HP
- 9-10 Studs: 80 HP
- 10-13 Studs: 50 HP

### Distance
*This information is not known but its likely to be infinite*

## Attachments
This weapon is not know to be able to have any attachments
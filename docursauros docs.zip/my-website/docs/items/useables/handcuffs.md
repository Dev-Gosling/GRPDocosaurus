---
sidebar_position: 1
---

# Handcuffs
The Handcuffs are used to Detain, Search, Arrest and put People in Cars.
## Use for the Item
Police officers can use the Handcuffs to detain People if they are a suspect, they can search peoples inventories for illegal items, check if they are wanted, drag them around, put them in cars and arrest them

:::caution Arresting people without them being wanted or having illegal items
Trying to arrest a person whitout them being wanted or having an illegal item in their inventory will make you fined $500 and the person will be undetained automaticly.
:::

## How to use
Police officers can use this Item while standing behind a person and pressing the Key `E` or clicking on the prompt for 3 Seconds, the person must walk slower than 1.5 studs per seconds `(5 Walkspeed)`

:::tip Team-Bound Item
This item is only for the Police Team and can only be used by the Police team.
:::
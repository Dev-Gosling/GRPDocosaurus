---
sidebar_position: 1
---

# Lockpick
The Lockpick is used to Crack-Open Doors.

## Use for Item
The Lockpick is used to open doors from houses and apartments.
To use the Lockpick you need to be near a door and Press `E` or click the Prompt

## The Lockpick Minigame
To successfully crack-open the door you need to click the screen at the exact moment when a bar hovers over the line in the middle of the box.

:::tip BEST USE
To avoid Police to come to your location when you rob a house you should rob a house or apartment where is not too much police activity.
:::

:::caution Illegal Item
This item is Illegal and the Police Team can arrest you if you have it in your inventory or in the trunk.
:::
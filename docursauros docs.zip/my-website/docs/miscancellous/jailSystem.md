---
sidebar_position: 1
---

# Arresting System
The Arresting System.

## How long do I go in jail for when I get arrested?
Its an pretty easy formular to know how long you get arrested for.
For every [Wanted-Star](/docs/miscancellous/wantedSystem) you'll get arrested for 1 Minute, means if you have 5 [Wanted-Stars](/docs/miscancellous/wantedSystem) you'll be in Prison for 5 Minutes.
Now if you have illegal Items in your Inventory you'll be send to jail 30 Seconds more for every illegal Item you have in your inventory.
:::info EXAMPLE
Heres a example for how long you will go in Prison if you have:
- 3 [Wanted-Stars](/docs/miscancellous/wantedSystem)
- A [M9](/docs/items/weapons/m9)
- A [Bat](/docs/items/weapons/bat)
- 1 [C4](/docs/items/useables/c4)

`(3x60)+30+30+30` = `270 Seconds` = `4.5 Minutes` 
:::

## How can I avoid being arrested?
### While being detained
If you are being detained you can **rapidly** click the Screen to break free from the cuffs, once you start clicking the Screen the officer dragging you have to click against it. If the bar at the bottom at the screen is fully green you will break free, but if you break free you'll automaticly get 2 [Wanted-Stars](/docs/miscancellous/wantedSystem)

If you are being detained on no officer is dragging you there will just be a text over your character telling people nearby that you are trying to break free, a officer nearby then has to rapidly click so you wont break free.

If you dont manage to break free in under 30 Seconds you cannot try again.

### While not being Detained
#### While having [Wanted-Stars](/docs/miscancellous/wantedSystem)
When you have [Wanted-Stars](/docs/miscancellous/wantedSystem) the most obvious way of avoiding getting arrested is to hide from the Police.

#### Whithout having [Wanted-Stars](/docs/miscancellous/wantedSystem)
If you dont wanna be arrested even if your not wanted is easy: Drive Normally, have no illegal Items with you and dont try to run from the cops.

:::tip TIP SO YOU CAN BREAK FREE
Try to break free when your detained and no officer is currently dragging you, the best moment would be when the officers are currently distracted
:::
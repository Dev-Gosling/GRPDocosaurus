---
sidebar_position: 1
---

# Wanted System
The Wanted System.

## How to get Wanted-Stars?
You get wanted if you commit a crime for example:
- Killing Someone
- Doing a Robbery
- Rob a person
- etc...

## What is a Wanted-Star?
A Wanted-Star diterminates what Level of Crime you committed, if you get 2 Wanted-Stars for Killing a Person and you killed 2 Persons, you'll receive 4 Wanted-Stars, 2 Wanted-Stars for the first kill and another 2 Wanted-Stars for the second.

## How to get rid of Wanted-Stars?
You can only get rid by them if you wait.
A Wanted-Star only lasts for 1 Minute, means if you have 5 Wanted-Stars after 1 Minute you have 4 left and after 3 Minutes you still have 2 Stars left, and so on..
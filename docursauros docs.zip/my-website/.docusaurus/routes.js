import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/__docusaurus/debug',
    component: ComponentCreator('/__docusaurus/debug', 'ccf'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/config',
    component: ComponentCreator('/__docusaurus/debug/config', 'e6d'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/content',
    component: ComponentCreator('/__docusaurus/debug/content', '236'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/globalData',
    component: ComponentCreator('/__docusaurus/debug/globalData', 'cd1'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/metadata',
    component: ComponentCreator('/__docusaurus/debug/metadata', 'f9f'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/registry',
    component: ComponentCreator('/__docusaurus/debug/registry', '4a7'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/routes',
    component: ComponentCreator('/__docusaurus/debug/routes', '2ca'),
    exact: true
  },
  {
    path: '/docs/tags',
    component: ComponentCreator('/docs/tags', 'c7b'),
    exact: true
  },
  {
    path: '/docs/tags/intro',
    component: ComponentCreator('/docs/tags/intro', 'c05'),
    exact: true
  },
  {
    path: '/docs/tags/introduction',
    component: ComponentCreator('/docs/tags/introduction', '80b'),
    exact: true
  },
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page', '569'),
    exact: true
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs', '426'),
    routes: [
      {
        path: '/docs/category/items',
        component: ComponentCreator('/docs/category/items', '7d5'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/category/locations',
        component: ComponentCreator('/docs/category/locations', '9e0'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/category/miscancellous',
        component: ComponentCreator('/docs/category/miscancellous', 'af8'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/category/tools',
        component: ComponentCreator('/docs/category/tools', '50b'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/category/tutorial---basics',
        component: ComponentCreator('/docs/category/tutorial---basics', 'd44'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/category/useables',
        component: ComponentCreator('/docs/category/useables', 'ce3'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/category/weapons',
        component: ComponentCreator('/docs/category/weapons', 'cea'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/intro',
        component: ComponentCreator('/docs/intro', 'aed'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/items/markdown-features',
        component: ComponentCreator('/docs/items/markdown-features', '673'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/items/tools/lockpick',
        component: ComponentCreator('/docs/items/tools/lockpick', '112'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/items/useables/c4',
        component: ComponentCreator('/docs/items/useables/c4', '929'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/items/useables/handcuffs',
        component: ComponentCreator('/docs/items/useables/handcuffs', '4a6'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/items/weapons/bat',
        component: ComponentCreator('/docs/items/weapons/bat', '4c0'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/items/weapons/m9',
        component: ComponentCreator('/docs/items/weapons/m9', '9b2'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/items/weapons/rocketlauncher',
        component: ComponentCreator('/docs/items/weapons/rocketlauncher', '7e4'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/locations/info-about-locations',
        component: ComponentCreator('/docs/locations/info-about-locations', 'fda'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/miscancellous/jailSystem',
        component: ComponentCreator('/docs/miscancellous/jailSystem', 'cb1'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/miscancellous/wantedSystem',
        component: ComponentCreator('/docs/miscancellous/wantedSystem', 'bd5'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/congratulations',
        component: ComponentCreator('/docs/tutorial-basics/congratulations', '793'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/docs/tutorial-basics/create-a-blog-post', '68e'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/create-a-document',
        component: ComponentCreator('/docs/tutorial-basics/create-a-document', 'c2d'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/create-a-page',
        component: ComponentCreator('/docs/tutorial-basics/create-a-page', 'f44'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/docs/tutorial-basics/deploy-your-site', 'e46'),
        exact: true,
        sidebar: "tutorialSidebar"
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/', 'f94'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
